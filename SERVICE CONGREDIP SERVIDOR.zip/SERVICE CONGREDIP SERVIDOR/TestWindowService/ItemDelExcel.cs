﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServicioEnvioPerformer
{
    class ItemDelExcel
    {

        public ItemDelExcel(string columna1, string columna2, string columna3, string columna4, string columna5, 
                            string columna6, string columna7, string columna8, string columna9,
                            string columna10, string columna11, string columna12, string columna13,
                            string columna14, string columna15, string columna16, string columna17,
                            string columna18, string columna19, string columna20, string columna21)
        {
            Columna1 = columna1;
            Columna2 = columna2;
            Columna3 = columna3;
            Columna4 = columna4;
            Columna5 = columna5;
            Columna6 = columna6;
            Columna7 = columna7;
            Columna8 = columna8;
            Columna9 = columna9;
            Columna10 = columna10;
            Columna11 = columna11;
            Columna12 = columna12;
            Columna13 = columna13;
            Columna14 = columna14;
            Columna15 = columna15;
            Columna16 = columna16;
            Columna17 = columna17;
            Columna18 = columna18;
            Columna19 = columna19;
            Columna20 = columna20;
            Columna21 = columna21;
        }

        public string Columna1 { get; set; }
        public string Columna2 { get; set; }
        public string Columna3 { get; set; }
        public string Columna4 { get; set; }
        public string Columna5 { get; set; }
        public string Columna6 { get; set; }
        public string Columna7 { get; set; }
        public string Columna8 { get; set; }
        public string Columna9 { get; set; }
        public string Columna10 { get; set; }
        public string Columna11 { get; set; }
        public string Columna12 { get; set; }
        public string Columna13 { get; set; }
        public string Columna14 { get; set; }
        public string Columna15 { get; set; }
        public string Columna16 { get; set; }
        public string Columna17 { get; set; }
        public string Columna18 { get; set; }
        public string Columna19 { get; set; }
        public string Columna20 { get; set; }
        public string Columna21 { get; set; }
    }
}
