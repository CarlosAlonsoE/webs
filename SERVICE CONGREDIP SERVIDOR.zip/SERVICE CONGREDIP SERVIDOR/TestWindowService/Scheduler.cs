﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
//using LinqToExcel;
using System.Data.SqlClient;
using System.Collections;
using System.Net;
using System.ServiceProcess;
using System.Text;
using Ionic.Zip;
using SpreadsheetLight;
using System.Timers;
using System.Threading.Tasks;
using System.Collections.Concurrent;

namespace ServicioEnvioPerformer
{
    public partial class Scheduler : ServiceBase
    {
        //string URL = "http://pdw.performer-project.eu/api/";
        //string urlParameters = "dss/sites/2/series";
        static string directorActual = @"C:\ServicioPERFORMER\";
        //string rutaProcesarBat = @"C:\ServicioPERFORMER\procesarSeries.bat";
        //string rutaConexionIgreen = "data source = igreensvr02; initial catalog = iGreenDelasLetras; user id = sa; password = 1gr33n5qLS4";
        //string rutaExcelVariables = @"C:\ServicioPERFORMER\Lista_de_variables.xlsx";
        //string nombreHojaLibroVariables = "iGreen-->PDW";
        //string rutaFicherosTSV = @"C:\ServicioPERFORMER\FicherosTSV";
        //string rutaFicherosZip = @"C:\ServicioPERFORMER\Ficheros.zip";

        string rutaProcesarBat = directorActual + @"procesarSeries.bat";
        string rutaConexionIgreen = "data source = igreensvr02; initial catalog = iGreenDelasLetras; user id = sa; password = 1gr33n5qLS4; Connection Timeout = 600";
        string rutaExcelVariables = directorActual + @"Lista_de_variables.xlsx";
        string nombreHojaLibroVariables = "iGreen-->PDW";
        string rutaFicherosTSV = directorActual + @"FicherosTSV";
        string rutaFicherosZip = directorActual + @"Ficheros.zip";
        string rutaDirectorioFTPArchivosBMS = @"\\ecdnsexternal\Performer";
        string rutaArchivosBMS = @"C:\ServicioPERFORMER\ArchivosBMS";
        //las rutas de las copias de seguridad
        string directorioCopiaSincronos = @"C:\ServicioPERFORMER\ArchivosBMS\Sincronos";
        string directorioCopiaAsincronos = @"C:\ServicioPERFORMER\ArchivosBMS\Asincronos";
        //string fechaArranqueServicio = "01/04/2016 03:00:00.0"; //debe estar en el formato del servidor donde se ejecute: 3/31/2016 1:06:07 PM
        string fechaArranqueServicio = "06/23/2016 03:00:00 AM"; //==>> mes/dia/año hora:minutos:segundos AM/PM debe estar en el formato del servidor donde se ejecute: 3/31/2016 1:06:07 PM
        //string fechaArranqueServicio = "06/22/2016 05:55:00 PM";

        private Timer timer1 = null;
        //private Timer timer2 = null;
        private int numEjecucion = 0;

        public Scheduler()
        {
            InitializeComponent();
        }

        /* Metodo que se inicia la comenzar el Servicio Windows configurando la fecha de la primera ejecución */
        protected override void OnStart(string[] args)
        {
            try
            {
                DateTime ahora = DateTime.Now;
                DateTime fechaConvertida = new DateTime();
                DateTime.TryParse(fechaArranqueServicio, out fechaConvertida);
                // Cálculo de la diferencia en milisegundos desde ahora hasta la hora de arranque del Servicio.
                TimeSpan ts = fechaConvertida - ahora;
                // Diferencias en:
                int difDias = ts.Days;
                int difHoras = ts.Hours;
                int difMinutos = ts.Minutes;
                int difSegundos = ts.Seconds;
                int difMilisegundos = ts.Milliseconds;
                //24hs son 86400000
                //(dias * 24hs/dia * 60min/hr * 60s/min * 1000ms/s) + (horas * 60min/hr * 60s/min * 1000ms/s) + (minutos * 60s/min * 1000ms/s) + (segundos * 1000ms/s) + milisegundos
                int milisegundos = difDias * 24 * 60 * 60 * 1000 + difHoras * 60 * 60 * 1000 + difMinutos * 60 * 1000 + difSegundos * 1000 + difMilisegundos;

                timer1 = new Timer();
                this.timer1.Interval = milisegundos; //Diferencia en milisegundos hasta la hora de arranque del Servicio (solo se ejecutará una vez este Timer.  
                this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(this.timer1_Tick);
                timer1.Enabled = true;
                Library.WriteErrorLog("El servicio PERFORMER ha arrancado. Ejecución de subida en " + milisegundos + "ms.");
            }
            catch (Exception)
            {
                Library.WriteErrorLog("El servicio PERFORMER no ha arrancado. Posible problema con la fecha de arranque del servicio.");
            }

        }

        /* Metodo que según la fecha de tiempo estipulada en milisegundos realiza el envío de datos correspondiente la primera vez 
         * y en el que se configuran las siguientes ejecuciones cada 24horas. */
        private void timer1_Tick(object sender, ElapsedEventArgs e)
        {            
            ejecucionPrincipal();
            int milisegundosSiguientes = 86400000; // cada 24 horas 1000milisegundos*60segundos*60minutos*24horas // 1000 * 60 * 3;//cada 3 minutos para pruebas
            this.timer1.Interval = milisegundosSiguientes;//cada 3 minutos para pruebas // 86400000; // cada 24 horas 1000milisegundos*60segundos*60minutos*24horas
            Library.WriteErrorLog(" Próxima ejecución de subida en " + milisegundosSiguientes + "ms.");
        }

        /* Metodo de ejecucion principal para la subida de datos */
        private void ejecucionPrincipal() {
            try
            {
                Library.WriteErrorLog("---------- Comienza obtención de datos Igreen ----------");
                ObtenerDatosIgreen();
                Library.WriteErrorLog("---------- Finalizada obtención de datos Igreen y comienza obtención de datos BMS ----------");
                ObtenerDatosBMS();
                Library.WriteErrorLog("---------- Finalizada obtención de datos BMS y comienza subida de series a PDW ----------");
                //creamos el ZIP sobreescribiendo existente,conteniendo los FicherosTSV creados de cada variable --> solo habrá TSV de las que tienen datos
                if (CrearZip(rutaFicherosTSV, rutaFicherosZip))
                {
                    Library.WriteErrorLog("Ficheros.zip creado en: " + rutaFicherosZip);
                }
                else
                {
                    Library.WriteErrorLog("El archivo Ficheros.zip no ha podido ser creado. Revise si existe la carpeta FicherosTSV y contiene archivos TSV.");
                }
                SubirSeries();
                Library.WriteErrorLog("---------- Finalizada subida de series a PDW ----------");
                numEjecucion++;
            }
            catch (Exception ex)
            {
                Library.WriteErrorLog("|||||||||||******* Error: " + ex + " **********|||||||||||||");
            }        
        }

        protected override void OnStop()
        {
            timer1.Enabled = false;
            Library.WriteErrorLog("El servicio de envío de series ha parado.");
        }

        /* Metodo para obtener la serie de datos de DeLasLetras de igreen segun la lista de variables ya definidas, creación de ficheros TSV y compresión en un fichero zip*/
        private void ObtenerDatosIgreen()
        {
            //ruta conexion base datos DeLasLetras Igreen
            string sCnnSQLIgreen = rutaConexionIgreen;

            //estructura para guardar los datos del excel
            List<ItemDelExcel> datosExcel = new List<ItemDelExcel>();

            //Ruta donde esta el archivo excel a leer
            string rutaExcel = rutaExcelVariables;
            
            SLDocument sl = new SLDocument(rutaExcel);
            sl.SelectWorksheet(nombreHojaLibroVariables);
            int contFila = 1;
            // leemos el excel y guardamos sus datos
            while (sl.GetCellValueAsString(contFila, 1) != "")
            {

                string columna1 = sl.GetCellValueAsString(contFila, 1);
                string columna2 = sl.GetCellValueAsString(contFila, 2);
                string columna3 = sl.GetCellValueAsString(contFila, 3);
                string columna4 = sl.GetCellValueAsString(contFila, 4);
                string columna5 = sl.GetCellValueAsString(contFila, 5);
                string columna6 = sl.GetCellValueAsString(contFila, 6);
                string columna7 = sl.GetCellValueAsString(contFila, 7);
                string columna8 = sl.GetCellValueAsString(contFila, 8);
                string columna9 = sl.GetCellValueAsString(contFila, 9);
                string columna10 = sl.GetCellValueAsString(contFila, 10);
                string columna11 = sl.GetCellValueAsString(contFila, 11);
                string columna12 = sl.GetCellValueAsString(contFila, 12);
                string columna13 = sl.GetCellValueAsString(contFila, 13);
                string columna14 = sl.GetCellValueAsString(contFila, 14);
                string columna15 = sl.GetCellValueAsString(contFila, 15);
                string columna16 = sl.GetCellValueAsString(contFila, 16);
                string columna17 = sl.GetCellValueAsString(contFila, 17);
                string columna18 = sl.GetCellValueAsString(contFila, 18);
                string columna19 = sl.GetCellValueAsString(contFila, 19);
                string columna20 = sl.GetCellValueAsString(contFila, 20);
                string columna21 = sl.GetCellValueAsString(contFila, 21);

                //estructura para guardar los datos del excel
                ItemDelExcel itemExcel = new ItemDelExcel(columna1,columna2,columna3,columna4,columna5,columna6,columna7,columna8,columna9,
                                                          columna10,columna11,columna12,columna13,columna14,columna15,columna16,columna17,columna18,
                                                          columna19,columna20,columna21);
                datosExcel.Add(itemExcel);
                //Library.WriteErrorLog("c1:" + columna1 + ",c2:" + columna2 + ",c3:" + columna3 +
                //                      ",c4:" + columna4 + ",c5:" + columna5 + ",c6:" + columna6 + 
                //                      ",c7:" + columna7 + ",c8:" + columna8 + ",c9:" + columna9);
                contFila++;
            }
            Library.WriteErrorLog("Datos de variables xlsx leidas");


            ////Creamos el objeto libro excel
            //var libroDatos = new ExcelQueryFactory(rutaExcel);
            //string nombreArchivo = rutaExcel.Substring(rutaExcel.LastIndexOf(@"\"));
            //string nombreHojaLibro = nombreHojaLibroVariables;

            ////Consultamos los datos del excel con Linq
            try
            {
                ////Padre	  Hijo	 name	label.fr	label.*	  type	  unit
                //var resultadoDatos = (from filaExcel in libroDatos.Worksheet(nombreHojaLibro)
                //                      let itemExcel = new ItemDelExcel
                //                      {
                //                          columna1 = filaExcel[0].Cast<string>(),
                //                          columna2 = filaExcel[1].Cast<string>(),
                //                          columna3 = filaExcel[2].Cast<string>(),
                //                          columna4 = filaExcel[3].Cast<string>(),
                //                          columna5 = filaExcel[4].Cast<string>(),
                //                          columna6 = filaExcel[5].Cast<string>(),
                //                          columna7 = filaExcel[6].Cast<string>(),
                //                          columna8 = filaExcel[7].Cast<string>(),
                //                          columna9 = filaExcel[8].Cast<string>()
                //                      }
                //                      select itemExcel).ToList();

                ////liberamos el objeto libro excel tras la lectura
                //libroDatos.Dispose();

                //obtenemos la fecha de ayer del sistema en forma de string y quitando las separaciones
                string fecha = DateTime.Today.AddDays(-1).ToShortDateString();

                //ponemos la fecha en el formato admitido en la base de datos de igreen para la consulta siguiente
                string[] arrayFecha = fecha.Split('/');
                fecha = int.Parse(arrayFecha[2]).ToString("0000") + int.Parse(arrayFecha[0]).ToString("00") + int.Parse(arrayFecha[1]).ToString("00");

                //Transformamos la colección en una colección para su tratamiento concurrente de forma segura
                ConcurrentBag<ItemDelExcel> datosDelExcel = new ConcurrentBag<ItemDelExcel>(datosExcel);

                //recorremos cada fila leida del excel para llenar la estructura de variables y para 
                //consultar por cada una los datos de dicho sensor en el último día entre las 00:00:00hs y las 23:59:59hs
                //foreach (var it in datosExcel)
                Parallel.ForEach(datosDelExcel, new ParallelOptions { MaxDegreeOfParallelism = 4 }, (it) =>
                {
                    //almacenamos el mínimo y máximo definido en la variable para posterior comprobación del valor que subamos de IGreen
                    string minimo = it.Columna16;
                    string maximo = it.Columna18;

                    //inicializamos la estructura que almacenará los datos consultados a la base de datos de igreen para cada variable
                    ConcurrentQueue<String> DatosIgreen = new ConcurrentQueue<string>();

                    //consultamos a la BBDD de igreen
                    string consultaIgreen = "SELECT * FROM RDATOS " +
                                            "WHERE estsenide = " +
                                            "(" +
                                                "SELECT ide	FROM estsensores WHERE padide = (SELECT ide FROM estsensores WHERE (des = '" + it.Columna1 + "')) AND des = '" + it.Columna2 + "'" +
                                            ")" +
                                            "AND (fecha = " + fecha + ")" +
                                            "AND (hora BETWEEN 000000 AND 235959);";
                    SqlCommand sCommand;
                    sCommand = new SqlCommand();
                    sCommand.Connection = new SqlConnection(sCnnSQLIgreen);
                    sCommand.CommandText = consultaIgreen.ToString();
                    sCommand.CommandTimeout = 6000; //tiempo de espera en segundos
                    sCommand.Connection.Open();
                    SqlDataReader reader = sCommand.ExecuteReader();
                    //Library.WriteErrorLog("Consulta ejecutada:" + consultaIgreen);

                    //recorremos cada dato leido y lo almacenamos en la estructura ArrayList inicializada previamente
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            string estsenide = reader.GetInt32(1).ToString();
                            string fechaValor = reader.GetInt32(2).ToString();
                            string horaValor = reader.GetInt32(3).ToString("D6");
                            //string valor = reader.GetDouble(4).ToString().Replace(",", ".");
                            //string valor = comprobarValor(reader.GetDouble(4), minimo, maximo).Replace(",", ".");
                            string valor = reader.GetDouble(4).ToString().Replace(",", ".");
                            if ((minimo != "-") && (maximo != "-"))
                            {
                                valor = comprobarValor(reader.GetDouble(4).ToString(), double.Parse(minimo), double.Parse(maximo)).Replace(",", ".");
                            }
                            //string valor = comprobarValor(reader.GetDouble(4).ToString(), double.Parse(minimo), double.Parse(maximo)).Replace(",", ".");

                            string fechaFormateada = darFormatoFecha(fechaValor, horaValor);
                            //DatosIgreen.Add(fechaFormateada + "\t" + valor);
                            //Encolamos cada dato en la estructura de cola FIFO para tratamiento concurrente seguro
                            DatosIgreen.Enqueue(fechaFormateada + "\t" + valor);
                        }
                    }
                    else { 
                        if (!(it.Columna1.Contains("Padre"))) { 
                            Library.WriteErrorLog("La consulta de padre: '" + it.Columna1 + "' e hijo: '" + it.Columna2 + "' no devuelve medidas.");
                        }
                    }
                    
                    //Cerramos command
                    sCommand.Connection.Close();

                    //creamos .tsv de la variable en cuestion con el nombre_de_la_variable.tsv solo si hay datos de dicha variable
                    if (DatosIgreen.Count > 0)
                    {
                        string rutaTSVvariable = rutaFicherosTSV + @"\" + it.Columna3 + ".tsv";
                        StringBuilder sb1 = new StringBuilder();
                        foreach (string lineaDatos in DatosIgreen)
                        {
                            sb1.AppendLine(lineaDatos);
                        }
                        try
                        {
                            FileInfo file = new FileInfo(rutaTSVvariable);
                            lock (file)
                            {
                                StreamWriter writer = file.CreateText();
                                writer.Write(sb1.ToString().Replace("\r",""));
                                writer.Close();
                            }
                            ////FileStream fichero = File.Open(rutaTSVvariable,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite);
                            ////UnicodeEncoding unicoding = new UnicodeEncoding();
                            ////fichero.Lock(0, unicoding.GetByteCount(sb1.ToString()));
                            ////fichero.Write(unicoding.GetBytes(sb1.ToString()), 0, unicoding.GetByteCount(sb1.ToString()));                  
                            //File.WriteAllText(rutaTSVvariable, sb1.ToString());
                            ////Quitamos los retornos de carro y dejamos solo LF en vez de CR+LF
                            ////fichero.Read(unicoding.GetBytes(sb1.ToString()), 0, unicoding.GetByteCount(sb1.ToString()));
                            //string text = File.ReadAllText(rutaTSVvariable);
                            //text = text.Replace("\r", "");
                            //File.WriteAllText(rutaTSVvariable, text);
                        }
                        catch (Exception)
                        {
                            Library.WriteErrorLog("Error al leer o escribir en : " + rutaTSVvariable + " está siendo usada por otro proceso.");
                        }

                    }
                });//Fin proceso bucle con hilos (Parallel.ForEach)
            }
            catch (Exception exc)
            {
                Library.WriteErrorLog("Error al intentar leer los datos del archivo excel: " + exc);
            }
        }

        //protected virtual bool estaBloqueado(string rutaCompletaArchivo)
        //{
        //    FileInfo file = new FileInfo(rutaCompletaArchivo);
        //    FileStream stream = null;

        //    try
        //    {
        //        stream = file.Open(FileMode.Open, FileAccess.Read, FileShare.None);
        //    }
        //    catch (IOException)
        //    {
        //        //el fichero no está disponible porque está todavía siendo escrito o procesado por otro hilo o no existe (ya ha sido procesado)
        //        return true;
        //    }
        //    finally
        //    {
        //        if (stream != null)
        //            stream.Close();
        //    }

        //    //file is not locked
        //    return false;
        //}


        /*
         * Método para obtener los archivos BMS de la ruta FTP en una carpeta y preparar su subida 
         * a PDW segun sea un archivo con datos sincronos o con asincronos -
         */
        private void ObtenerDatosBMS()
        {

            ////Las ruta debe ser la del directorio con los archivos BMS
            //string rutaDirectorioFTPArchivosBMS = @"\\ecdnsexternal\Performer";
            //string rutaArchivosBMS = @"C:\CARLOS ALONSO\10. ECPERFORMER\ENVIO A PERFORMER\archivosBMS";
            try
            {
                //copiamos los archivos a la ruta de preparación de datos
                IList ficherosBMS = new ArrayList();
                DirectoryInfo di = new DirectoryInfo(rutaDirectorioFTPArchivosBMS);
                foreach (var fi in di.GetFiles())
                {
                    ficherosBMS.Add(fi.FullName);
                    string nombre = fi.Name;
                    if (nombre.Contains("values")) { 
                        nombre = "values.csv";
                        crearCopiasSeguridad(directorioCopiaSincronos, fi.FullName, directorioCopiaSincronos + @"\" + fi.Name);
                    } else 
                    { 
                        nombre = "events.csv";
                        crearCopiasSeguridad(directorioCopiaAsincronos, fi.FullName, directorioCopiaAsincronos + @"\" + fi.Name); 
                    }
                    ////Si ya existe lo borramos y copiamos el nuevo
                    //if (File.Exists(rutaArchivosBMS + @"\" + fi.Name))
                    //{
                    //    File.Delete(rutaArchivosBMS + @"\" + fi.Name);
                    //}
                    //File.Copy(fi.FullName, rutaArchivosBMS + @"\" + fi.Name,true);
                    File.Copy(fi.FullName, rutaArchivosBMS + @"\" + nombre, true);

                }
                Library.WriteErrorLog("Los archivos BMS se han copiado correctamente.");

                di = new DirectoryInfo(rutaArchivosBMS);
                foreach (var fi in di.GetFiles())
                {
                    //Según el tipo de fichero sea de valores sincronos o asincronos realizamos un tratamiento distinto
                    if (fi.FullName.Contains("values"))
                    {
                        //crearCopiasSeguridad(directorioCopiaSincronos, fi.FullName, directorioCopiaSincronos + @"\" + fi.Name);
                        ficheroValoresSincronosBMS(fi.FullName);
                    }
                    else
                    {
                        //crearCopiasSeguridad(directorioCopiaAsincronos, fi.FullName, directorioCopiaAsincronos + @"\" + fi.Name);
                        ficheroValoresAsincronosBMS(fi.FullName);
                    }

                }

            }
            catch (Exception exc)
            {
                Library.WriteErrorLog("No se han podido copiar los archivos, revise el directorio con los errores. Error: " + exc);
            }

        }

        /* Tratamiento de fichero con datos Sincronos de BMS */
        private void ficheroValoresSincronosBMS(string rutaFichero)
        {

            ArrayList fechas = new ArrayList();
            ArrayList nombreVariableBMS = new ArrayList();
            List<String> nombresVBMSDistintos = new List<String>();
            ArrayList valoresBMS = new ArrayList();
            //inicializamos la estructura que almacenará los datos consultados al archivo BMS para cada variable
            ArrayList DatosBMS = new ArrayList();

            string file_string = File.ReadAllText(rutaFichero);
            string[] arrayLineas = file_string.Split('\n');//el separador es una nueva linea
            for (int i = 0; i < arrayLineas.Count() - 1; i++)
            {
                string[] arrayLinea = arrayLineas[i].Split(';');
                fechas.Add(arrayLinea[0]);//primer campo
                nombreVariableBMS.Add(arrayLinea[1] + "." + arrayLinea[2]);//nombre variable campo
                valoresBMS.Add(arrayLinea[3]);//ultimo campo
                if (nombresVBMSDistintos.Contains(nombreVariableBMS[i].ToString())) { /*nada*/} else { nombresVBMSDistintos.Add(nombreVariableBMS[i].ToString()); }
                DatosBMS.Add(nombreVariableBMS[i] + ";" + formateandoFecha(fechas[i].ToString()) + "\t" + valoresBMS[i].ToString().Replace(',', '.'));
            }

            foreach (string nom in nombresVBMSDistintos)
            {
                ArrayList DatosVariableBMS = new ArrayList();
                foreach (string dat in DatosBMS)
                {
                    string[] arrayDat = dat.Split(';');
                    string nombre = arrayDat[0];
                    string datos = arrayDat[1];
                    if (nombre.Equals(nom))
                    {
                        DatosVariableBMS.Add(datos);
                    }
                }

                //creamos .tsv de la variable en cuestion con el nombre_de_la_variable.tsv solo si hay datos de dicha variable
                if (DatosVariableBMS.Count > 0)
                {
                    string rutaTSVvariable = rutaFicherosTSV + @"\" + nom + ".tsv";
                    StringBuilder sb1 = new StringBuilder();
                    foreach (string lineaDatos in DatosVariableBMS)
                    {
                        sb1.AppendLine(lineaDatos);
                    }
                    File.WriteAllText(rutaTSVvariable, sb1.ToString());
                    //Quitamos los retornos de carro y dejamos solo LF en vez de CR+LF
                    string text = File.ReadAllText(rutaTSVvariable);
                    text = text.Replace("\r", "");
                    File.WriteAllText(rutaTSVvariable, text);
                }

            }

            Library.WriteErrorLog("Ficheros TSV Sincronos preparados.");
        }

        /* Tratamiento de fichero con datos Asincronos de BMS */
        private void ficheroValoresAsincronosBMS(string rutaFichero)
        {

            List<String> fechas = new List<String>();
            List<String> nombreVariableBMS = new List<String>();
            List<String> nombresVBMSDistintos = new List<String>();
            List<String> valoresBMS = new List<String>();
            //inicializamos la estructura que almacenará los datos consultados al archivo BMS para cada variable
            List<String> DatosBMS = new List<String>();

            string file_string = File.ReadAllText(rutaFichero);
            string[] arrayLineas = file_string.Split('\n');//el separador es el de la nueva linea
            for (int i = 0; i < arrayLineas.Count() - 1; i++)
            {
                string[] arrayLinea = arrayLineas[i].Split(';');
                fechas.Add(arrayLinea[0]);//primer campo
                nombreVariableBMS.Add(arrayLinea[1] + "." + arrayLinea[2]);//nombre variable campo
                valoresBMS.Add(arrayLinea[3]);//ultimo campo
                if (nombresVBMSDistintos.Contains(nombreVariableBMS[i].ToString())) { /*nada*/} else { nombresVBMSDistintos.Add(nombreVariableBMS[i].ToString()); }
                DatosBMS.Add(nombreVariableBMS[i] + ";" + formateandoFecha(fechas[i].ToString()) + ";" + valoresBMS[i].ToString().Replace(',', '.'));
            }


            foreach (string nom in nombresVBMSDistintos)
            {

                List<String> DatosUnicosVariable = new List<String>();
                List<String> DatosVariableBMS = new List<String>();
                foreach (string linea in DatosBMS)
                {
                    string[] arrayLineaBMS = linea.Split(';');
                    string nombre = arrayLineaBMS[0];
                    if (nombre.Equals(nom))
                    {
                        DatosUnicosVariable.Add(linea);
                    }
                }

                int valor = 0;
                for (int hr = 0; hr < 24; hr++)
                {
                    for (int mi = 0; mi < 60; mi = mi + 5)
                    {
                        int hora = hr, minuto = mi;
                        List<String> filasIntervalo = buscarFilasIntervalo(hr, mi, DatosUnicosVariable, DatosVariableBMS);
                        if (filasIntervalo.Count == 0)
                        {
                            if (DatosVariableBMS.Count > 0)
                            {
                                //obtenemos el valor de la ultima línea añadida
                                string ultimaFilaRegistrada = DatosVariableBMS[DatosVariableBMS.Count - 1];
                                string[] arrayUltimaFilaRegistrada = ultimaFilaRegistrada.Split('\t');
                                //obtenemos la última hora minuto de la última línea añadida
                                string[] arrayUltimoDia = arrayUltimaFilaRegistrada[0].Split('T');
                                string[] arrayUltimaHsMin = arrayUltimoDia[1].Split(':');
                                int ultimaHora = int.Parse(arrayUltimaHsMin[0]);
                                int ultimoMinuto = int.Parse(arrayUltimaHsMin[1]);
                                //solo pintamos si el último minuto es distinto al nuevo
                                if (ultimoMinuto != mi) { DatosVariableBMS.Add(obtenerDia(DatosBMS[0]) + "T" + hr.ToString("00") + ":" + mi.ToString("00") + ":00.000" + "\t" + valor); }
                            }
                            else
                            {
                                DatosVariableBMS.Add(obtenerDia(DatosBMS[0]) + "T" + hr.ToString("00") + ":" + mi.ToString("00") + ":00.000" + "\t" + valor);
                            }
                        }
                        else
                        {
                            //obtenemos el valor de la ultima línea añadida
                            string ultimaFilaRegistrada = DatosVariableBMS[DatosVariableBMS.Count - 1];
                            string[] arrayUltimaFilaRegistrada = ultimaFilaRegistrada.Split('\t');
                            int ultimoValor = int.Parse(arrayUltimaFilaRegistrada[1]);
                            //obtenemos la última hora minuto de la última línea añadida
                            string[] arrayUltimoDia = arrayUltimaFilaRegistrada[0].Split('T');
                            string[] arrayUltimaHsMin = arrayUltimoDia[1].Split(':');
                            int ultimaHora = int.Parse(arrayUltimaHsMin[0]);
                            int ultimoMinuto = int.Parse(arrayUltimaHsMin[1]);
                            //string segundos = arrayHsMin[2];
                            //obtenemos el valor de la nueva línea que queremos añadir para poder mantenerla
                            string nuevaFilaAPintar = filasIntervalo[filasIntervalo.Count - 1];
                            string[] arrayNuevaFilaAPintar = nuevaFilaAPintar.Split('\t');
                            int nuevoValor = int.Parse(arrayNuevaFilaAPintar[1]);
                            //obtenemos la hora minuto de la línea a añadir
                            string[] arrayNuevoDia = arrayNuevaFilaAPintar[0].Split('T');
                            string[] arrayNuevoHsMin = arrayNuevoDia[1].Split(':');
                            int nuevaHora = int.Parse(arrayNuevoHsMin[0]);
                            int nuevoMinuto = int.Parse(arrayNuevoHsMin[1]);
                            //Utilizamos el valor de la nueva línea
                            //if ((ultimaHora == nuevaHora) && (nuevoMinuto != ultimoMinuto + 5) && (ultimoMinuto != nuevoMinuto)) { DatosVariableBMS.Add(obtenerDia(DatosBMS[0]) + "T" + hr.ToString("00") + ":" + mi.ToString("00") + ":00.000" + "\t" + valor); }
                            valor = nuevoValor;
                            string filaAPintar = arrayNuevaFilaAPintar[0] + '\t' + valor;
                            if (ultimoMinuto != nuevoMinuto) { DatosVariableBMS.Add(filaAPintar); }
                        }
                    }
                }

                //creamos .tsv de la variable en cuestion con el nombre_de_la_variable.tsv solo si hay datos de dicha variable
                if (DatosVariableBMS.Count > 0)
                {
                    string rutaTSVvariable = rutaFicherosTSV + @"\" + nom + ".tsv";
                    StringBuilder sb1 = new StringBuilder();
                    foreach (string lineaDatos in DatosVariableBMS)
                    {
                        sb1.AppendLine(lineaDatos);
                    }
                    File.WriteAllText(rutaTSVvariable, sb1.ToString());
                    //Quitamos los retornos de carro y dejamos solo LF en vez de CR+LF
                    string text = File.ReadAllText(rutaTSVvariable);
                    text = text.Replace("\r", "");
                    File.WriteAllText(rutaTSVvariable, text);
                }

            }

            Library.WriteErrorLog("Ficheros TSV Asincronos preparados.");
        }

        /* Metodo que busca las filas existentes en un intervalo de 5 minutos */
        private List<String> buscarFilasIntervalo(int hr, int min, List<String> DatosUnicosVariable, List<String> DatosVariableBMS)
        {

            List<String> lineasEnIntervalo = new List<String>();
            foreach (string linea in DatosUnicosVariable)
            {
                string[] arrayLineaBMS = linea.Split(';');
                string nombre = arrayLineaBMS[0];
                string valor = arrayLineaBMS[2];
                string[] arrayDia = arrayLineaBMS[1].Split('T');
                string[] arrayHsMin = arrayDia[1].Split(':');
                int hora = int.Parse(arrayHsMin[0]);
                int minutos = int.Parse(arrayHsMin[1]);
                string segundos = arrayHsMin[2];
                if ((hora == hr) && (minutos >= min) && (minutos < min + 5))
                {
                    if (existeLinea(hora, int.Parse(minRedondeados(minutos)), DatosVariableBMS) == false)
                    {
                        //lineasEnIntervalo.Add(arrayDia[0] + "T" + hora.ToString("00") + ":" + minRedondeados(minutos) + ":" + segundos + "\t" + valor.Replace(',', '.'));
                        lineasEnIntervalo.Add(arrayDia[0] + "T" + hora.ToString("00") + ":" + minRedondeados(minutos) + ":" + "00.000" + "\t" + valor.Replace(',', '.'));
                    }
                }

            }

            return lineasEnIntervalo;
        }

        /* Método para comprobar si ya existe una línea de hora y minuto en el listado*/
        private Boolean existeLinea(int hr, int min, List<String> DatosVariableBMS)
        {
            int contador = 0;
            foreach (string linea in DatosVariableBMS)
            {
                string[] arrayLineaBMS = linea.Split('T');
                string[] arrayHsMin = arrayLineaBMS[1].Split(':');
                int hora = int.Parse(arrayHsMin[0]);
                int minutos = int.Parse(arrayHsMin[1]);
                string segundos = arrayHsMin[2];
                if ((hora == hr) && (minutos == min)) { contador++; }
            }
            if (contador > 1) { return true; } else { return false; }
        }

        /* Metodo para comprimir en un archivo zip distintos archivos, sin directorios en jerarquia de la raiz - usamos referencia a ionic.zip de DotNetZip.1.9.8 */
        public bool CrearZip(string rutaDirectorio, string rutaDestinoZip)
        {
            bool comprimido = false;
            IList<string> listaDeArchivos = new List<string>();
            DirectoryInfo di = new DirectoryInfo(rutaDirectorio);
            foreach (var fi in di.GetFiles())
            {
                listaDeArchivos.Add(fi.FullName);
            }

            if (listaDeArchivos.Count > 0)
            {
                using (ZipFile archivoZip = new ZipFile())
                {
                    archivoZip.AddFiles(listaDeArchivos, false, "");
                    archivoZip.Save(rutaDestinoZip);
                    comprimido = true;
                }
            }

            return comprimido;
        }

        /* Metodo para devolver un string con el formato de fecha: 2015/02/24T00:23:18.607000 dadas fecha y hora */
        private string darFormatoFecha(string fechaValor, string horaValor)
        {
            string fechaFormateada = "";
            string fecha = fechaValor.Substring(0, 4) + "/" + fechaValor.Substring(4, 2) + "/" + fechaValor.Substring(6, 2);
            string hora = horaValor.Substring(0, 2) + ":" + horaValor.Substring(2, 2) + ":" + horaValor.Substring(4, 2);
            fechaFormateada = fecha + "T" + hora + ".000";
            return fechaFormateada;
        }

        /* Metodo para devolver un string con el formato de fecha: 2015/02/24T00:23:18.607 dada fecha en otro formato */
        private string formateandoFecha(string fecha)
        {
            string dia = "";
            string hora = "";
            string[] arrayFecha = fecha.Split(' ');
            dia = arrayFecha[0].Replace('-', '/');
            //string[] arrayDia = dia.Split('/');
            //string fechaInversa = arrayDia[2] + "-" + arrayDia[1] + "-" + arrayDia[0];
            hora = arrayFecha[1];
            //if (int.Parse(hora.Substring(0, hora.IndexOf(":"))) < 10) { hora = "0" + hora; }
            return dia + "T" + hora + ".000";

        }

        /* Metodo para Subir las series de datos comprimidas en el archivo comprimido segun especificación */
        private void SubirSeries()
        {
            try
            {   
                // Ejecutamos procesarSeries.bat que con cURL sube las series de datos contenidas en el archivo Ficheros.zip del mismo directorio creado previamente
                System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo(rutaProcesarBat);
                // Indicamos que la salida del proceso se redireccione en un Stream
                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.UseShellExecute = false;
                //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
                procStartInfo.CreateNoWindow = false;
                //Inicializa el proceso
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = procStartInfo;
                Library.WriteErrorLog("Comenzando proceso: " + rutaProcesarBat);
                proc.Start();
                //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
                string result = proc.StandardOutput.ReadToEnd();
                //Muestra en el log la salida del Comando
                Library.WriteErrorLog(result);
                //Muestra en el log el estado del trabajo si es que anteriormente se ha generado un JobId
                if (result.Contains("job_id"))
                {
                    int indIni = result.IndexOf("job_id\":");
                    int indLong = result.IndexOf("}", result.IndexOf(("job_id\":")));
                    int total = result.Length;
                    string SubcadenaJobId = result.Substring(indIni, indLong - indIni);
                    string jobid = SubcadenaJobId.Substring(SubcadenaJobId.IndexOf(":") + 1);
                    //Library.WriteErrorLog(result);
                    Library.WriteErrorLog("Estado del trabajo generado (" + jobid + "): " + estadoTrabajo(jobid) );
                }
                else {
                    Library.WriteErrorLog("La llamada cURL no se ha realizado. Compruebe permisos, rutas y archivos necesarios.");
                }

            }

            catch (Exception ex)
            {
                Library.WriteErrorLog("ERROR: " + ex.Message + "Traza: " + ex.StackTrace);
            }     
        }

        /* Metodo auxiliar para comprobar el estado del trabajo de la serie de datos subida */
        private string estadoTrabajo(string jobId)
        {
            var syncClientG = new WebClient();
            var resp = "";
            string URL = "http://pdw.performer-project.eu/api/";
            string urlParameters = "dss/sites/2/jobs/" + jobId + "/status";

            syncClientG.Headers[HttpRequestHeader.ContentType] = "application/json; charset=utf-8";
            syncClientG.Headers[HttpRequestHeader.Accept] = "application/json";

            resp = syncClientG.DownloadString(URL + urlParameters);

            return resp;
        }

        /* Metodo auxiliar para comprobar si el valor está entre un mínimo y un máximo */
        private string comprobarValor(string valor, double minimo, double maximo)
        {
            double valorASubir = double.Parse(valor);
            if (valorASubir < minimo) { valorASubir = minimo; }
            if (valorASubir > maximo) { valorASubir = maximo; }

            return valorASubir.ToString();
        }

        /* Metodo auxiliar que redondea los minutos cada 5 minutos al entero más bajo
         * Por ejemplo: 40->40, 41->40, 42->40, 43->40, 44->40, 45->45, 46->45,...
         */
        private string minRedondeados(int minutos)
        {

            int resto = minutos % 5;
            switch (resto)
            {
                case 0: break; //si acaba en 0 o 5 los minutos no cambian
                case 1: minutos = minutos - 1; break; //si acaban en 1 disminuyen 1 minuto
                case 2: minutos = minutos - 2; break; //si acaban en 2 disminuyen 2 minutos
                case 3: minutos = minutos - 3; break; //si acaban en 3 disminuyen 3 minutos
                case 4: minutos = minutos - 4; break; //si acaban en 4 disminuyen 4 minutos
            }
            return minutos.ToString("00");
        }

        /* Método para comprobar si ya existe una línea de hora y minuto en el listado*/
        private String obtenerDia(string lineaBMS)
        {
            string[] arrayLineaBMS = lineaBMS.Split(';');
            string[] arrayDia = arrayLineaBMS[1].Split('T');
            return arrayDia[0];
        }

        /* Metodo auxiliar para crear una copia de seguridad de un archivo, en un directorio especificado que se crea si no existe */
        private void crearCopiasSeguridad(string rutaDirectorio, string rutaArchivoACopiar, string nombreArchivoCopiaSeguridad)
        {

            // Determinamos si el directorio existe
            if (Directory.Exists(rutaDirectorio))
            {
                Library.WriteErrorLog("El directorio " + rutaDirectorio + " ya existe y no se creará de nuevo.");
                try
                {
                    File.Copy(rutaArchivoACopiar, nombreArchivoCopiaSeguridad, false);
                }
                catch (Exception)
                {
                    Library.WriteErrorLog("El archivo " + nombreArchivoCopiaSeguridad + " ya existe y no se creará de nuevo.");
                }
            }
            else
            {
                // Try to create the directory.
                DirectoryInfo di = Directory.CreateDirectory(rutaDirectorio);
                File.Copy(rutaArchivoACopiar, nombreArchivoCopiaSeguridad, false);
                Library.WriteErrorLog("El directorio no existía, se ha creado y se ha copiado el archivo a las " + Directory.GetCreationTime(rutaDirectorio));
            }

        }

    }
}
